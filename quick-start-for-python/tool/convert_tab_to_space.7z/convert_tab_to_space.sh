#!/bin/sh
#------------------
# Desc:
#    将python代码中的tab转为spaces
# Args:
#    src_path
#------------------

SRC_PATH=../branch/

#### 可在脚本开始运行时调用，打印当前的时间及PID。
job_start() {
    echo "$(eval $NOW) job_start"

    cd $SRC_PATH
    find $PYC_PATH -name '*.py' -exec sed -i 's/\t/    /g' {} +
    job_success "执行完毕"
}

#### 可在脚本执行成功的逻辑分支处调用，打印当时的时间戳及PID
job_success() {
    MSG="$*"
    echo "$(eval $NOW) job_success:[$MSG]"
    exit 0
}

#### 可在脚本执行失败的逻辑分支处调用，打印当时的时间戳及PID
job_fail() {
    MSG="$*"
    echo "$(eval $NOW) job_fail:[$MSG]"
    exit 1
}

job_start
